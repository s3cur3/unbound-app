//
//  ImageViewController.m
//  Unbound5
//
//  Created by Bob on 10/6/12.
//  Copyright (c) 2012 Pixite Apps LLC. All rights reserved.
//

#import "ImageViewController.h"

@interface ImageViewController ()

@end

@implementation ImageViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

-(void)awakeFromNib
{
    NSLog(@"awakeFromNib");
    [self.view setWantsLayer:YES];
}

-(void)setRepresentedObject:(id)representedObject
{
    [super setRepresentedObject:representedObject];
}

-(id)representedObject
{
    return [super representedObject];
}

@end
