//
//  ScrollViewWorkaround.h
//  IKImageViewDemo
//
//  Created by Nicholas Riley on 1/25/10.
//  Copyright 2010 Nicholas Riley. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface ScrollViewWorkaround : NSScrollView {

}

@end
